import React from 'react';
export default function ChartComponent() {
  return (
    <div>
      <h4 style={{ margin: '0 0 10px 0', fontSize: '14px', color: '#9ca3af' }}>📊 Fluxo de Caixa Operacional</h4>
      <div style={{ height: '60px', background: '#030712', borderRadius: '5px', display: 'flex', itemsAlign: 'end', padding: '5px', gap: '5px' }}>
        <div style={{ width: '33%', background: '#2563eb', height: '40%' }}></div>
        <div style={{ width: '33%', background: '#2563eb', height: '70%' }}></div>
        <div style={{ width: '33%', background: '#2563eb', height: '100%' }}></div>
      </div>
    </div>
  );
}
