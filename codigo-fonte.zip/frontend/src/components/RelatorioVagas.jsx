import React from 'react';
export default function RelatorioVagas({ dados }) {
  return (
    <div style={{ background: '#111827', border: '1px solid #1f2937', padding: '20px', borderRadius: '10px' }}>
      <h3 style={{ margin: '0 0 15px 0' }}>💼 Pipeline de Vagas (ATS)</h3>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
        {dados.map(v => (
          <div key={v.id} style={{ background: '#030712', padding: '10px', borderRadius: '5px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <p style={{ margin: 0, fontSize: '14px' }}>{v.cargo}</p>
              <p style={{ margin: 0, fontSize: '11px', color: '#6b7280' }}>{v.departamento}</p>
            </div>
            <span style={{ fontSize: '12px', color: '#818cf8', background: '#1e1b4b', padding: '2px 8px', borderRadius: '4px' }}>{v.status}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
