import React, { useState, useEffect } from 'react';
import api from '../services/api';
import RelatorioColaboradores from './RelatorioColaboradores';
import RelatorioPagamentos from './RelatorioPagamentos';
import RelatorioVagas from './RelatorioVagas';
import ChartComponent from './ChartComponent';

export default function Dashboard() {
  const [role, setRole] = useState('RH_Gestor');
  const [colaboradores, setColaboradores] = useState([]);
  const [pagamentos, setPagamentos] = useState([]);
  const [vagas, setVagas] = useState([]);
  const [erroServidor, setErroServidor] = useState(null);
  const [autenticado, setAutenticado] = useState(false);

  useEffect(() => {
    async function realizarAutenticacaoELoad() {
      try {
        setErroServidor(null);
        const resLogin = await api.post('/api/login', {
          email: "admin@unisceid.ac.mz",
          password: "SuperSenhaSegura2026!",
          roleSimulada: role
        });
        localStorage.setItem('token_rh_secure', resLogin.data.token);
        setAutenticado(true);

        const [resColabs, resVagas] = await Promise.all([
          api.get('/api/colaboradores'),
          api.get('/api/vagas')
        ]);
        setColaboradores(resColabs.data);
        setVagas(resVagas.data);

        if (role === 'RH_Gestor' || role === 'Admin') {
          const resPags = await api.get('/api/pagamentos');
          setPagamentos(resPags.data);
        } else {
          setPagamentos([]);
        }
      } catch (error) {
        setErroServidor("⚠️ Falha na validação do token JWT ou privilégios de rede insuficientes.");
        setColaboradores([]);
        setPagamentos([]);
        setVagas([]);
      }
    }
    realizarAutenticacaoELoad();
  }, [role]);

  return (
    <div style={{ padding: '20px', background: '#0b0f19', minHeight: '100vh', color: '#f3f4f6', fontFamily: 'sans-serif' }}>
      <header style={{ borderBottom: '1px solid #1f2937', paddingBottom: '20px', marginBottom: '20px', display: 'flex', justifyContent: 'between', alignItems: 'center' }}>
        <div>
          <h1 style={{ fontSize: '24px', margin: 0 }}>🏢 Sistema RH | Control Panel</h1>
          <p style={{ fontSize: '12px', color: '#10b981', margin: '5px 0 0 0' }}>✓ Status: {autenticado ? "🔒 Autenticado JWT" : "🔄 Validando..."}</p>
        </div>
        <div>
          <label style={{ marginRight: '10px', fontSize: '12px', color: '#9ca3af' }}>Perfil (RBAC):</label>
          <select value={role} onChange={(e) => setRole(e.target.value)} style={{ background: '#1f2937', color: '#fff', border: '1px solid #374151', padding: '5px', borderRadius: '5px' }}>
            <option value="RH_Gestor">👑 Perfil: RH_Gestor</option>
            <option value="RH_Recrutador">🛡️ Perfil: RH_Recrutador</option>
          </select>
        </div>
      </header>
      {erroServidor && <div style={{ background: '#7f1d1d', border: '1px solid #b91c1c', padding: '10px', borderRadius: '5px', marginBottom: '20px', fontSize: '14px' }}>{erroServidor}</div>}
      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '20px' }}>
        <div>
          <RelatorioColaboradores dados={colaboradores} />
          <div style={{ marginTop: '20px' }}><RelatorioVagas dados={vagas} /></div>
        </div>
        <div>
          {(role === 'RH_Gestor' || role === 'Admin') && <RelatorioPagamentos dados={pagamentos} />}
          <div style={{ background: '#111827', border: '1px solid #1f2937', padding: '20px', borderRadius: '10px', marginTop: '20px' }}>
            <ChartComponent />
          </div>
        </div>
      </div>
    </div>
  );
}
