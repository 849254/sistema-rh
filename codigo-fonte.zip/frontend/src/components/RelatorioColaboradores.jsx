import React from 'react';
export default function RelatorioColaboradores({ dados }) {
  return (
    <div style={{ background: '#111827', border: '1px solid #1f2937', padding: '20px', borderRadius: '10px' }}>
      <h3 style={{ margin: '0 0 15px 0' }}>📋 Relatório de Colaboradores</h3>
      <table style={{ width: '100%', textAlgin: 'left', borderCollapse: 'collapse' }}>
        <thead>
          <tr style={{ color: '#9ca3af', fontSize: '12px', borderBottom: '1px solid #374151' }}>
            <th style={{ paddingBottom: '10px' }}>Nome</th>
            <th style={{ paddingBottom: '10px' }}>Contrato</th>
            <th style={{ paddingBottom: '10px', textAlign: 'right' }}>Salário</th>
          </tr>
        </thead>
        <tbody>
          {dados.map(c => (
            <tr key={c.id} style={{ borderBottom: '1px solid #1f2937', fontSize: '14px' }}>
              <td style={{ padding: '10px 0' }}>{c.nome}</td>
              <td style={{ padding: '10px 0', color: '#9ca3af' }}>{c.tipoContrato}</td>
              <td style={{ padding: '10px 0', textAlign: 'right', color: c.salario.includes('🔒') ? '#f87171' : '#34d399', fontWeight: 'bold' }}>{c.salario}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
