import React from 'react';
export default function RelatorioPagamentos({ dados }) {
  return (
    <div style={{ background: '#111827', border: '1px solid #1f2937', padding: '20px', borderRadius: '10px' }}>
      <h3 style={{ margin: '0 0 15px 0' }}>💳 Histórico de Pagamentos</h3>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
        {dados.map(p => (
          <div key={p.id} style={{ background: '#030712', padding: '10px', borderRadius: '5px', border: '1px solid #1f2937', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <p style={{ margin: 0, fontSize: '14px', fontWeight: 'bold' }}>{p.nome}</p>
              <p style={{ margin: 0, fontSize: '11px', color: '#6b7280' }}>{p.data} • Processado</p>
            </div>
            <span style={{ fontSize: '12px', color: '#34d399', fontWeight: 'bold' }}>{p.valor}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
