import axios from 'axios';

const api = axios.create({
  baseURL: 'http://localhost:3000',
  timeout: 5000
});

// Intercetor de Segurança: Injeta o Token JWT em todas as chamadas HTTP
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token_rh_secure');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
}, (error) => {
  return Promise.reject(error);
});

export default api;
