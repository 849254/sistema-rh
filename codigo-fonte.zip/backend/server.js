const express = require('express');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const { Pool } = require('pg');
const bcrypt = require('bcryptjs');
require('dotenv').config();

const app = express();
app.use(express.json());

app.use(cors({
  origin: 'http://localhost:5173',
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

const pool = new Pool({
  user: process.env.DB_USER,
  host: process.env.DB_HOST,
  database: process.env.DB_NAME,
  password: process.env.DB_PASSWORD,
  port: parseInt(process.env.DB_PORT || '5434'),
  max: 20,
  idleTimeoutMillis: 30000
});

const JWT_SECRET = process.env.JWT_SECRET || 'unisceid_fe_gestao_gs_phd_2026_token_secure_key';

function verificarAcesso(rolesPermitidas) {
  return (req, res, next) => {
    const authHeader = req.headers['authorization'];
    if (!authHeader) return res.status(401).json({ error: "Token ausente." });

    const token = authHeader.split(' ')[1];
    try {
      const decoded = jwt.verify(token, JWT_SECRET);
      req.user = decoded;
      if (!rolesPermitidas.includes(decoded.role)) {
        return res.status(403).json({ error: "🔒 Acesso Negado." });
      }
      next();
    } catch (err) {
      return res.status(403).json({ error: "Sessão expirada." });
    }
  };
}

app.post('/api/login', async (req, res) => {
  const { email, roleSimulada } = req.body;
  const token = jwt.sign({ email, role: roleSimulada || 'RH_Gestor' }, JWT_SECRET, { expiresIn: '1h' });
  res.json({ token, role: roleSimulada || 'RH_Gestor' });
});

app.get('/api/colaboradores', verificarAcesso(['RH_Gestor', 'RH_Recrutador', 'Admin']), async (req, res) => {
  try {
    if (req.user.role === 'RH_Gestor' || req.user.role === 'Admin') {
      // MONETÁRIO: Atualizado para Meticais (MT) conforme a praça financeira de Moçambique
      return res.json([
        { id: '1', nome: "Ana Silva", tipoContrato: "CLT/Efetivo", salario: "32.000,00 MT" },
        { id: '2', nome: "Carlos Souza", tipoContrato: "PJ/Prestador", salario: "45.000,00 MT" },
        { id: '3', nome: "John Doe", tipoContrato: "CLT/Efetivo", salario: "28.000,00 MT" }
      ]);
    } else {
      return res.json([
        { id: '1', nome: "Ana Silva", tipoContrato: "CLT/Efetivo", salario: "🔒 ACESSO NEGADO" },
        { id: '2', nome: "Carlos Souza", tipoContrato: "PJ/Prestador", salario: "🔒 ACESSO NEGADO" },
        { id: '3', nome: "John Doe", tipoContrato: "CLT/Efetivo", salario: "🔒 ACESSO NEGADO" }
      ]);
    }
  } catch (err) {
    res.status(500).json({ error: "Erro no servidor." });
  }
});

app.get('/api/vagas', (req, res) => {
  res.json([
    { id: '1', cargo: "Desenvolvedor Full Stack Senior", departamento: "TI", status: "Em Aberto" },
    { id: '2', cargo: "Analista de Segurança da Informação", departamento: "Segurança", status: "Entrevistas" }
  ]);
});

app.get('/api/pagamentos', verificarAcesso(['RH_Gestor', 'Admin']), (req, res) => {
  // MONETÁRIO: Atualizado o histórico de Payroll líquido para Meticais
  res.json([
    { id: "1", nome: "Ana Silva", valor: "28.480,00 MT", data: "17/09/2026" },
    { id: "2", nome: "John Doe", valor: "24.920,00 MT", data: "17/09/2026" }
  ]);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`🚀 Backend Enterprise rodando na porta ${PORT}`));
