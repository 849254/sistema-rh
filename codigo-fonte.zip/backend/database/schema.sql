-- ============================================================================
-- FACULDADE DE ECONOMIA E GESTÃO - CURSO DE GESTÃO DE SISTEMAS DE INFORMAÇÃO
-- AVALIAÇÃO III: SISTEMA DE GESTÃO DE RECURSOS HUMANOS (SRH)
-- ARQUITETURA DE BANCO DE DADOS RELACIONAL SEGURO (POSTGRESQL)
-- ============================================================================

-- Ativar extensão para geração de UUIDs criptográficos (Prevenção de ataques de enumeração)
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Limpeza preventiva de tabelas caso o script seja reexecutado (Rollback limpo)
DROP TABLE IF EXISTS audit_logs CASCADE;
DROP TABLE IF EXISTS salary_payments CASCADE;
DROP TABLE IF EXISTS contracts CASCADE;
DROP TABLE IF EXISTS vacancies_ats CASCADE;
DROP TABLE IF EXISTS employees CASCADE;
DROP TABLE IF EXISTS users CASCADE;

-- 1. TABELA DE UTILIZADORES (Autenticação e Controle de Acessos Baseado em Funções - RBAC)
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL, -- Senhas armazenadas com Hash forte (Argon2id ou Bcrypt)
    role VARCHAR(50) NOT NULL CHECK (role IN ('Admin', 'RH_Gestor', 'RH_Recrutador', 'Colaborador')),
    mfa_enabled BOOLEAN DEFAULT FALSE,
    mfa_secret VARCHAR(128),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 2. TABELA DE COLABORADORES (Informações Pessoais Identificáveis - PII)
CREATE TABLE employees (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    full_name VARCHAR(255) NOT NULL,
    tax_id_encrypted TEXT NOT NULL,       -- NIF/CPF encriptado na camada de aplicação (AES-256-GCM)
    phone_encrypted TEXT,                 -- Contacto encriptado para mitigar risco de vazamento (LGPD/RGPD)
    hire_date DATE NOT NULL DEFAULT CURRENT_DATE,
    status VARCHAR(50) DEFAULT 'Active' CHECK (status IN ('Active', 'Suspended', 'Terminated')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 3. TABELA DE CONTRATOS E REMUNERAÇÕES (Dados Financeiros Críticos Criptografados)
CREATE TABLE contracts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    employee_id UUID REFERENCES employees(id) ON DELETE CASCADE,
    contract_type VARCHAR(100) NOT NULL CHECK (contract_type IN ('CLT/Efetivo', 'PJ/Prestador', 'Estágio', 'Temporário')),
    base_salary_encrypted TEXT NOT NULL,  -- Salário bruto codificado. Nunca exposto em texto limpo no BD
    allowances_encrypted TEXT,            -- Subsídios/Bónus encriptados
    currency VARCHAR(3) DEFAULT 'MZN',    -- Moeda padrão (Metical de Moçambique) ou EUR conforme o escopo
    start_date DATE NOT NULL,
    end_date DATE,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 4. TABELA DE RECRUTAMENTO (Módulo ATS - Applicant Tracking System)
CREATE TABLE vacancies_ats (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title VARCHAR(255) NOT NULL,
    department VARCHAR(150) NOT NULL,
    status VARCHAR(50) DEFAULT 'Em Aberto' CHECK (status IN ('Em Aberto', 'Entrevistas', 'Preenchida', 'Cancelada')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 5. TABELA DE PAGAMENTOS EFETUADOS (Histórico de Payroll)
CREATE TABLE salary_payments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    employee_id UUID REFERENCES employees(id) ON DELETE RESTRICT,
    net_value_processed NUMERIC(12, 2) NOT NULL, -- Valor líquido calculado pelo motor puro
    payment_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(50) DEFAULT 'Processed' CHECK (status IN ('Pending', 'Processed', 'Failed'))
);

-- 6. TRILHA DE AUDITORIA IMUTÁVEL (Gestão de Riscos: Não-Repúdio e Detecção de Fraude)
CREATE TABLE audit_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID,                         -- Usuário que realizou a ação (Pode ser nulo se for sistema)
    action VARCHAR(100) NOT NULL,         -- EX: 'UPDATE_SALARY', 'VIEW_PII'
    table_name VARCHAR(100) NOT NULL,
    row_id UUID NOT NULL,
    old_values JSONB,                     -- Estado anterior dos dados (Para auditoria reversa)
    new_values JSONB,                     -- Novo estado modificado
    ip_address VARCHAR(45),               -- Gestão de Redes: IP do terminal de origem
    triggered_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- MECANISMOS DE INFRAESTRUTURA: TRIGGERS AUTOMÁTICOS DE AUDITORIA
-- ============================================================================

CREATE OR REPLACE FUNCTION process_salary_audit()
RETURNS TRIGGER AS $$
BEGIN
    IF (TG_OP = 'UPDATE') THEN
        INSERT INTO audit_logs (user_id, action, table_name, row_id, old_values, new_values)
        VALUES (
            NEW.employee_id, 
            'UPDATE_CONTRACT_SALARY', 
            'contracts', 
            NEW.id, 
            jsonb_build_object('base_salary', OLD.base_salary_encrypted),
            jsonb_build_object('base_salary', NEW.base_salary_encrypted)
        );
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_salary_modification
    AFTER UPDATE ON contracts
    FOR EACH ROW
    EXECUTE FUNCTION process_salary_audit();

